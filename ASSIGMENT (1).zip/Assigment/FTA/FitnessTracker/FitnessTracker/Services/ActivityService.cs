﻿using FitnessTracker.Models;
using System.Collections.Generic;

namespace FitnessTracker.Services
{
    public static class ActivityService
    {
        private static readonly Dictionary<string, List<ActivityLog>> userActivities = new();

        public static void AddActivity(ActivityLog log)
        {
            if (Session.CurrentUser == null) return;

            string username = Session.CurrentUser.Username;

            if (!userActivities.ContainsKey(username))
                userActivities[username] = new List<ActivityLog>();

            userActivities[username].Add(log);
            DatabaseService.SaveActivity(log);  // Still store in the DB
        }

        public static List<ActivityLog> GetActivitiesForCurrentUser()
        {
            if (Session.CurrentUser == null) return new List<ActivityLog>();

            string username = Session.CurrentUser.Username;

            if (!userActivities.TryGetValue(username, out var activities))
                return new List<ActivityLog>();

            return activities;
        }
    }
}
