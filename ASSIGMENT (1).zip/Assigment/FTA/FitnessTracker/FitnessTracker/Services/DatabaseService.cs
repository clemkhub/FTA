﻿using System;
using System.Data.SQLite;
using System.IO;
using FitnessTracker.Models;

namespace FitnessTracker.Services
{
    public static class DatabaseService
    {
        private static readonly string dbFile = "fitness_tracker.db";
        private static readonly string connectionString = $"Data Source={dbFile};Version=3;";

        static DatabaseService()
        {
            InitializeDatabase();
        }

        private static void InitializeDatabase()
        {
            if (!File.Exists(dbFile))
            {
                SQLiteConnection.CreateFile(dbFile);

                using (var connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();

                    var userTable = @"
                        CREATE TABLE Users (
                            Id INTEGER PRIMARY KEY AUTOINCREMENT,
                            Username TEXT NOT NULL UNIQUE,
                            Password TEXT NOT NULL
                        );";

                    var activityTable = @"
                        CREATE TABLE ActivityLogs (
                            Id INTEGER PRIMARY KEY AUTOINCREMENT,
                            ActivityType TEXT,
                            Steps REAL,
                            DistanceKm REAL,
                            ElevationGain REAL,
                            DurationMinutes REAL,
                            CaloriesBurned REAL,
                            Timestamp TEXT
                        );";

                    using var command = new SQLiteCommand(userTable + activityTable, connection);
                    command.ExecuteNonQuery();
                }
            }
        }

        public static void SaveUser(string username, string password)
        {
            using var connection = new SQLiteConnection(connectionString);
            connection.Open();

            var command = new SQLiteCommand("INSERT INTO Users (Username, Password) VALUES (@user, @pass)", connection);
            command.Parameters.AddWithValue("@user", username);
            command.Parameters.AddWithValue("@pass", password);

            command.ExecuteNonQuery();
        }

        public static bool ValidateUser(string username, string password)
        {
            using var connection = new SQLiteConnection(connectionString);
            connection.Open();

            var command = new SQLiteCommand("SELECT COUNT(*) FROM Users WHERE Username = @user AND Password = @pass", connection);
            command.Parameters.AddWithValue("@user", username);
            command.Parameters.AddWithValue("@pass", password);

            var count = Convert.ToInt32(command.ExecuteScalar());
            return count > 0;
        }

        public static void SaveActivity(ActivityLog log)
        {
            using var connection = new SQLiteConnection(connectionString);
            connection.Open();

            var cmd = new SQLiteCommand(@"
                INSERT INTO ActivityLogs 
                (ActivityType, Steps, DistanceKm, ElevationGain, DurationMinutes, CaloriesBurned, Timestamp)
                VALUES (@type, @steps, @distance, @elevation, @duration, @calories, @timestamp)", connection);

            cmd.Parameters.AddWithValue("@type", log.ActivityType);
            cmd.Parameters.AddWithValue("@steps", log.Steps);
            cmd.Parameters.AddWithValue("@distance", log.DistanceKm);
            cmd.Parameters.AddWithValue("@elevation", log.ElevationGain);
            cmd.Parameters.AddWithValue("@duration", log.DurationMinutes); 
            cmd.Parameters.AddWithValue("@calories", log.CaloriesBurned);
            cmd.Parameters.AddWithValue("@timestamp", log.Timestamp.ToString("s"));

            cmd.ExecuteNonQuery();
        }
    }
}
