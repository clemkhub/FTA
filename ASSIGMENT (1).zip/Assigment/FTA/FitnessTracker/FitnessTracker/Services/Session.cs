﻿using FitnessTracker.Models;

namespace FitnessTracker.Services
{
    public static class Session
    {
        public static User? CurrentUser { get; set; }
    }
}
