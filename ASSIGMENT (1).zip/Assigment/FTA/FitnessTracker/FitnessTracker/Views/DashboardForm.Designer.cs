﻿namespace FitnessTracker.Views
{
    partial class DashboardForm
    {
        private System.ComponentModel.IContainer components = null;
        private Label lblNickname;
        private Label lblGoal;
        private Label lblCalories;
        private ListBox lstRecentActivities;
        private TextBox txtNewGoal;
        private Button btnUpdateGoal;
        private Button btnLogActivity;
        private Label lblTips;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblNickname = new Label();
            lblGoal = new Label();
            lblCalories = new Label();
            lstRecentActivities = new ListBox();
            txtNewGoal = new TextBox();
            btnUpdateGoal = new Button();
            btnLogActivity = new Button();
            lblTips = new Label();
            BtnLogOut = new Button();
            lblTotalDistance = new Label();
            lblTotalSteps = new Label();
            SuspendLayout();
            // 
            // lblNickname
            // 
            lblNickname.AutoSize = true;
            lblNickname.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblNickname.Location = new Point(146, 20);
            lblNickname.Name = "lblNickname";
            lblNickname.Size = new Size(184, 32);
            lblNickname.TabIndex = 0;
            lblNickname.Text = "Welcome, User";
            // 
            // lblGoal
            // 
            lblGoal.AutoSize = true;
            lblGoal.Font = new Font("Segoe UI", 12F);
            lblGoal.Location = new Point(30, 70);
            lblGoal.Name = "lblGoal";
            lblGoal.Size = new Size(116, 21);
            lblGoal.TabIndex = 1;
            lblGoal.Text = "Goal: 2500 kcal";
            // 
            // lblCalories
            // 
            lblCalories.AutoSize = true;
            lblCalories.Font = new Font("Segoe UI", 12F);
            lblCalories.Location = new Point(30, 100);
            lblCalories.Name = "lblCalories";
            lblCalories.Size = new Size(107, 21);
            lblCalories.TabIndex = 2;
            lblCalories.Text = "Burned: 0 kcal";
            // 
            // lstRecentActivities
            // 
            lstRecentActivities.FormattingEnabled = true;
            lstRecentActivities.ItemHeight = 15;
            lstRecentActivities.Location = new Point(30, 140);
            lstRecentActivities.Name = "lstRecentActivities";
            lstRecentActivities.Size = new Size(400, 94);
            lstRecentActivities.TabIndex = 3;
            // 
            // txtNewGoal
            // 
            txtNewGoal.Location = new Point(30, 250);
            txtNewGoal.Multiline = true;
            txtNewGoal.Name = "txtNewGoal";
            txtNewGoal.PlaceholderText = "Enter new goal";
            txtNewGoal.Size = new Size(184, 31);
            txtNewGoal.TabIndex = 4;
            // 
            // btnUpdateGoal
            // 
            btnUpdateGoal.Location = new Point(271, 250);
            btnUpdateGoal.Name = "btnUpdateGoal";
            btnUpdateGoal.Size = new Size(100, 31);
            btnUpdateGoal.TabIndex = 5;
            btnUpdateGoal.Text = "Update Goal";
            btnUpdateGoal.UseVisualStyleBackColor = true;
            btnUpdateGoal.Click += BtnUpdateGoal_Click;
            // 
            // btnLogActivity
            // 
            btnLogActivity.Location = new Point(30, 318);
            btnLogActivity.Name = "btnLogActivity";
            btnLogActivity.Size = new Size(184, 38);
            btnLogActivity.TabIndex = 6;
            btnLogActivity.Text = "Log Activity";
            btnLogActivity.UseVisualStyleBackColor = true;
            btnLogActivity.Click += BtnLogActivity_Click;
            // 
            // lblTips
            // 
            lblTips.AutoSize = true;
            lblTips.Font = new Font("Segoe UI", 10F, FontStyle.Italic);
            lblTips.Location = new Point(30, 379);
            lblTips.Name = "lblTips";
            lblTips.Size = new Size(119, 19);
            lblTips.TabIndex = 7;
            lblTips.Text = "Random Tip here!";
            // 
            // BtnLogOut
            // 
            BtnLogOut.Location = new Point(271, 318);
            BtnLogOut.Name = "BtnLogOut";
            BtnLogOut.Size = new Size(168, 38);
            BtnLogOut.TabIndex = 8;
            BtnLogOut.Text = "Log out";
            BtnLogOut.UseVisualStyleBackColor = true;
            BtnLogOut.Click += BtnLogOut_Click;
            // 
            // lblTotalDistance
            // 
            lblTotalDistance.AutoSize = true;
            lblTotalDistance.Font = new Font("Segoe UI", 12F);
            lblTotalDistance.Location = new Point(292, 91);
            lblTotalDistance.Name = "lblTotalDistance";
            lblTotalDistance.Size = new Size(76, 21);
            lblTotalDistance.TabIndex = 9;
            lblTotalDistance.Text = "Distance: ";
            // 
            // lblTotalSteps
            // 
            lblTotalSteps.AutoSize = true;
            lblTotalSteps.Font = new Font("Segoe UI", 12F);
            lblTotalSteps.Location = new Point(292, 70);
            lblTotalSteps.Name = "lblTotalSteps";
            lblTotalSteps.Size = new Size(54, 21);
            lblTotalSteps.TabIndex = 10;
            lblTotalSteps.Text = "Steps: ";
            // 
            // DashboardForm
            // 
            ClientSize = new Size(500, 450);
            Controls.Add(lblTotalSteps);
            Controls.Add(lblTotalDistance);
            Controls.Add(BtnLogOut);
            Controls.Add(lblNickname);
            Controls.Add(lblGoal);
            Controls.Add(lblCalories);
            Controls.Add(lstRecentActivities);
            Controls.Add(txtNewGoal);
            Controls.Add(btnUpdateGoal);
            Controls.Add(btnLogActivity);
            Controls.Add(lblTips);
            Name = "DashboardForm";
            Text = "Dashboard";
            Load += DashboardForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }
        //private Button button1;
        private Button BtnLogOut;
        private Label lblTotalDistance;
        private Label lblTotalSteps;
    }
}
