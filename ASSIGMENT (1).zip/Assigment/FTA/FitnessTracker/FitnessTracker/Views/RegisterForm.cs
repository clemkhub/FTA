﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FitnessTracker.Services;

namespace FitnessTracker.Views
{
    public partial class RegisterForm : Form
    {
        public RegisterForm()
        {
            InitializeComponent();
            ApplyDarkTheme();
        }
        private void ApplyDarkTheme()
        {
            this.BackColor = ColorTranslator.FromHtml("#1E1E1E"); // Form Background

            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is Label lbl)
                {
                    lbl.ForeColor = ColorTranslator.FromHtml("#CCCCCC"); // Light Gray for labels
                }
                else if (ctrl is TextBox txt)
                {
                    txt.BackColor = ColorTranslator.FromHtml("#2D2D30"); // Dark background
                    txt.ForeColor = Color.White;                        // White text
                    txt.TextAlign = HorizontalAlignment.Center;         // Center text (especially placeholders)
                    txt.BorderStyle = BorderStyle.FixedSingle;           // Neat borders
                }
                else if (ctrl is Button btn)
                {
                    btn.BackColor = ColorTranslator.FromHtml("#007ACC"); // Blue button background
                    btn.ForeColor = Color.White;                         // White button text
                    btn.FlatStyle = FlatStyle.Flat;                      // Flat design
                    btn.FlatAppearance.BorderSize = 0;                   // No border
                }
                else if (ctrl is ListBox lst)
                {
                    lst.BackColor = ColorTranslator.FromHtml("#2D2D30"); // Same as textbox
                    lst.ForeColor = ColorTranslator.FromHtml("#CCCCCC");
                }
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.No)
            {
                e.Cancel = true;
            }

            base.OnFormClosing(e);
        }
        private void BtnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                string username = TxtUsername.Text.Trim();
                string password = TxtPassword.Text.Trim();
                string confirmPassword = TxtConfirmPassword.Text.Trim();

                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(confirmPassword))
                {
                    MessageBox.Show("All fields are required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (password != confirmPassword)
                {
                    MessageBox.Show("Passwords do not match.", "Password Mismatch", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (UserService.UserExists(username))
                {
                    MessageBox.Show("User already exists!", "Duplicate User", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                UserService.Register(username, password);
                MessageBox.Show("Registration successful! Please login.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Hide();
                var loginForm = new LoginForm();
                loginForm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An unexpected error occurred:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void LblLoginLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            LoginForm login = new LoginForm();
            login.Show();
            this.Hide();
        }
    }
}
